hello this is my roblox trade bot i made 



to start it download python 3.7 and clone this repository or download it and do this

`pip install httpx`

`pip install json`

after you install all of those you need to put your cookie in settings.py then:

`python main.py`

example output:

```
----Roblox trade bot----
   Made By: iranathan


Found 3 trades...

checking trade #1
trade #1 offer value is 7109
trade #1 request value is 4077
:pensive: trade #1 is bad you will lose -2539 robux
checking trade #2
trade #2 offer value is 3094
trade #2 request value is 2902
:pensive: trade #2 is bad you will lose -2467 robux
checking trade #3
trade #3 offer value is 6561
trade #3 request value is 6005
:pensive: trade #3 is bad you will lose -4495 robux
```